/**
 * Created by zhanghaibin on 2016/11/3.
 */

'use strict'
function setCookie(name,value,iDay){
	var oDate=new Date();
	
	if(iDay){
		document.cookie=name+'='+value+'; PATH=/; EXPIRES='+oDate.setDate(oDate.getDate()+iDay).toGMTString();
	}else{
		document.cookie=name+'='+value+'; PATH=/;';
	}
}


function getCookie(name){
	if(name){
		var arr=document.cookie.split('; ');
		for(var i=0; i<arr.length; i++){
			var arr2=arr[i].split('=');
			if(arr2[0]==name){
				return arr2[1];
			}
		}
	}
}

function removeCookie(name){
	setCookie(name,1,-1)
}

//随机数 n-m
function rnd(n, m) {
    return parseInt(Math.floor() * (m - n)) + n;
}

//在一个数组中找一个数是否存在
function findInArray(n, arr) {
    for (var i = 0; i < arr.length; i++) {
        if (n == arr[i]) {
            return true;
        }
    }
    return false;
}
//变成两位数
function toDou(n) {
    return n < 10 ? '0' + n : '' + n;
}

//事件绑定
function addEvent(obj, sEv, fn) {
    if (obj.addEventListener) {
        obj.addEventListener(sEv, fn, false);
    } else {
        obj.attachEvent('on' + sEv, fn)
    }
}
//事件解绑定
function removeEvent(obj, sEv, fn) {
    if (obj.removeEventListener) {
        obj.removeEventListener(sEv, fn, false);
    } else {
        obj.detachEvent('on' + sEv, fn);
    }

}
//加载完成
function domReady(fn) {
    if (document.addEventListener) {
        document.addEventListener('DOMContentLoaded', function () {
            fn && fn();
        }, false);
    } else {
        document.attachEvent('onreadystatechange', function () {
            //加载状态
            if (document.readyState == 'complete') {
                fn && fn();
            }
        });
    }
}

//碰撞
function collTest(obj1, obj2) {
    var l1 = obj1.offsetLeft;
    var r1 = l1 + obj1.offsetWidth;
    var t1 = obj1.offsetTop;
    var b1 = t1 + obj1.offsetHeight;

    var l2 = obj2.offsetLeft;
    var r2 = l2 + obj2.offsetWidth;
    var t2 = obj2.offsetTop;
    var b2 = t2 + obj2.offsetHeight;

    if (r1 > l2 && l1 < r2 && b1 > t2 && t1 < b2) {
        return true;
    } else {
        return false;
    }
}

//获取计算后的样式（兼容所有浏览器）
function getStyle(obj,sName){
	return (obj.currentStyle||getComputedStyle(obj,false))[sName];
}

////运动

//linear 匀速 ease-in 加速  ease-out 缓冲

function move(obj,json,options){
	var options=options||{};
	options.duration=options.duration||700;
	options.easing=options.easing||'ease-out';
	var start={};
	var dis={};
	for(var name in json){
		start[name]=parseInt(getStyle(obj,name));
		dis[name]=json[name]-start[name];
	}
	var count=Math.floor(options.duration/30);
	var n=0;
	
	clearInterval(obj.timer);
	obj.timer=setInterval(function (){
		n++;
		
		for(var name in json){
			switch(options.easing){
				case 'linear':
					var cur=start[name]+dis[name]*n/count;
					break;
				case 'ease-in':
					var a=n/count;
					var cur=start[name]+dis[name]*Math.pow(a,3);
					break;
				case 'ease-out':
					var a=1-n/count;
					var cur=start[name]+dis[name]*(1-Math.pow(a,3));
					break;
			}
			if(name=='opacity'){
				obj.style.filter='alpha(opacity:'+cur*100+')';
				obj.style.opacity=cur;
			}else{
				obj.style[name]=cur+'px';
			}
		}
		
		if(n==count){
			clearInterval(obj.timer);
		}
	},16);
}



//滚轴
function addWheel(obj, fn) {
    //加事件
    function addEvent(obj, sEv, fn) {
        if (obj.addEventListener) {
            obj.addEventListener(sEv, fn, false);
        }
        else {
            obj.attachEvent('on' + sEv, fn);
        }
    }

    function wheel(ev) {
        var oEvent = ev || event;
        //存一下，是否向下
        var bDown = oEvent.wheelDelta ? (oEvent.wheelDelta < 0) : (oEvent.detail > 0);
        //已知了滚动方向，可以做些事情了
        fn && fn(bDown);
        oEvent.preventDefault && oEvent.preventDefault();
        return false;

    }

    if (window.navigator.userAgent.toLowerCase().indexOf('firefox') != -1) {
        addEvent(obj, 'DOMMouseScroll', wheel)

    } else {
        addEvent(obj, 'mousewheel', wheel)
        //obj.onmousewheel = wheel;

    }
}
//阿贾克斯

function json2url(json){
	json.t = Math.random();
	var arr = [];
	for(var name in json){
		arr.push(name+'='+encodeURIComponent(json[name]));
	}
	return arr.join('&');
}
/*
 * url:请求地址
 * data:提交数据、参数
 * timeout:超时时间
 * type: get  post
 * success:fn
 * error:fn
 * */
function ajax(json){
	var json = json||{};
	if(!json.url)return;
	json.data = json.data || {};
	json.type = json.type || 'get';
	json.timeout = json.timeout || 5000;
	if(window.XMLHttpRequest){
		var oAjax = new XMLHttpRequest();
	}else{
		var oAjax = new ActiveXObject('Microsoft.XMLHTTP');
	}
	switch(json.type.toLowerCase()){
		case 'get':
			oAjax.open('GET',json.url+'?'+json2url(json.data),true);
			oAjax.send();
			break;
		case 'post':
			oAjax.open('POST',json.url,true);
			oAjax.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
			oAjax.send(json2url(json.data));
			break;
	}
	var timer = setTimeout(function(){
		oAjax.onreadystatechange=null;
		json.error&&json.error('亲，网络不给力');
	},json.timeout);
	oAjax.onreadystatechange=function(){
		if(oAjax.readyState==4){
			clearTimeout(timer);
			if(oAjax.status>=200&&oAjax.status<300||oAjax.status==304){
				json.success&&json.success(oAjax.responseText);
			}else{
				json.error&&json.error(oAjax.status);
			}
		}
	};
}

//jsonp
/**
 *
 * @param json
 * json.url  --  string  接口地址
 * json.data --  json    接口需要的参数
 * json.cbName  -- string   函数名字
 * json.success  --  function   成功的回调
 */
function jsonp(json) {
    var json = json || {};
    if (!json.url) {
        alert('jsongun');
        return;
    }
    json.data = json.data || {};
    json.cnName = json.cbName || 'cb';

    var fnName = 'jsonb_' + Math.random();
    fnName = fnName.replace('.', '');
    window[fnName] = function (json2) {
        json.success && json.success(json2);
	    //创建的script标签使用完，删除
        oHead.remove(oS);
    }
    var oS = document.createElement('script');

    json.data[json.cbName] = fnName;
    var arr = [];
    for (var name in json.data) {
        arr.push(name + '=' + json.data[name]);
    }
    oS.src = json.url + '?' + arr.json('&');

    var oHead = document.getElementById('head')[0];
    oHead.appendChild(oS);

}
